import os
from tkinter import *
import customtkinter as ctk
from tkinter import ttk
import tkinter as tk
from PIL import Image, ImageTk
# import tabula
import PyPDF2
import re
from tkinter.filedialog import askopenfilename
from PyPDF2 import PdfReader
from tkinter import font
from pdfminer.high_level import extract_text

root = Tk()


class App():
    def __init__(self):
        self.root = root
        self.tela()
        self.frames()
        #self.botoes()
        self.logo()

    def tela(self):
        """Definição da tela e sua cor total"""
        self.root.title("Sistema Confea")
        self.root.configure(background='#e8e8e8')
        self.root.geometry("1920x1080")
        self.root.resizable(True, True)
        self.root.minsize(850, 600)

    def frames(self):
        """Header azul"""
        self.frame_1 = Frame(self.root)
        self.frame_1.configure(background='#4a8ad4')
        self.frame_1.place(relx=0.0, rely=0.0, relwidth=1, relheight=0.2)

        """SubHeader cinza"""
        self.frame_3 = Frame(self.root)
        self.frame_3.configure(background='#adadad')
        self.frame_3.place(relx=0.0, rely=0.2, relwidth=1, relheight=0.05)

        """nav lateral azul"""
        self.frame_2 = Frame(self.root)
        self.frame_2.configure(background='#01509b')
        self.frame_2.place(relx=0.0, rely=0.25, relwidth=0.055, relheight=1)

        def textopadrao():
            self.pag59 = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
            self.pag59.insert(tk.INSERT, """aqui """)
            self.pag59.place(relx=0.065, rely=0.26, relwidth=0.925, relheight=0.66)
            return textopadrao
        def caixas():
                """Caixa AI"""
                self.caixaai = Text(self.root, bg='white', fg='black', bd=2 , font=('Times New Roman', 13))
                self.caixaai.insert(tk.INSERT,"                           AUTO DE INFRAÇÃO\nNº do Processo:\nArtigo:\nAutuado(a):\nCNPJ:\nMotivo:\nFolhas.:\nNº do AI:\nMulta:\nData:")
                self.caixaai.place(relx=0.065, rely=0.26, relwidth=0.46, relheight=0.18)

                """Caixa CE"""
                self.caixace = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixace.insert(tk.INSERT, "                           DECISÃO DA CÂMARA ESPECIALIZADA DO CREA\nFolhas.:\nDecisão nº:\nEspecialidade:\nMulta:\nData:")
                self.caixace.place(relx=0.54, rely=0.26, relwidth=0.45, relheight=0.11)

                """Caixa PL"""
                self.caixapl = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixapl.insert(tk.INSERT, "                           DECISÃO PLENÁRIO DO CREA\nFolhas.:\nDecisão nº:\nEspecialidade:\nMulta:\nData:")
                self.caixapl.place(relx=0.065, rely=0.45, relwidth=0.46, relheight=0.11)

                """Caixa AR"""
                self.caixaar = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixaar.insert(tk.INSERT, "                           AVISO DE RECEBIMENTO\nFolhas.:\nData:")
                self.caixaar.place(relx=0.54, rely=0.38, relwidth=0.22, relheight=0.06)

                """Caixa Tempestividade"""
                self.caixatempestividade = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixatempestividade.insert(tk.INSERT, "                           INTEMPESTIVIDADE\nDentro do prazo:\nDias:")
                self.caixatempestividade.place(relx=0.77, rely=0.38, relwidth=0.22, relheight=0.06)

                """Caixa RECURSO"""
                self.caixarecurso = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixarecurso.insert(tk.INSERT, "                           RECURSO AO CONFEA\nFolhas.:\nJustificativa 1:\nJustificativa 2:\nContrato:\nData:")
                self.caixarecurso.place(relx=0.065, rely=0.57, relwidth=0.46, relheight=0.11)

                """CaixA ART"""
                self.caixaart = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixaart.insert(tk.INSERT, "                           REGULARIZAÇÃO POR ANOTAÇÃO DE RESPONSABILIDADE TÉCNICA-ART\nFolhas.:\nNº da ART:\nData:")
                self.caixaart.place(relx=0.54, rely=0.45, relwidth=0.45, relheight=0.08)

                """Comprovante de Cadastro Nacional de Pessoa Juridica"""
                self.caixacnpj = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixacnpj.insert(tk.INSERT, "                           COMPROVANTE DE CADASTRO NACIONAL DE PESSOA JURÍDICA\nFolhas.:\nCNAE Primário:\nCNAE Secundário:\nData:")
                self.caixacnpj.place(relx=0.54, rely=0.54, relwidth=0.45, relheight=0.10)

                """SEI"""
                self.caixasei = Text(self.root, bg='white', fg='black', bd=2, font=('Times New Roman', 13))
                self.caixasei.insert(tk.INSERT, "                           SEI\nNumero:")
                self.caixasei.place(relx=0.54, rely=0.65, relwidth=0.45, relheight=0.04)

                return {
                    "caixaai": self.caixaai,
                    "caixace": self.caixace,
                    "caixapl": self.caixapl,
                    "caixaar": self.caixaar,
                    "caixatempestividade": self.caixatempestividade,
                    "caixarecurso": self.caixarecurso,
                    "caixaart": self.caixaart,
                    "caixacnpj": self.caixacnpj,
                    "caixasei": self.caixasei
                }
        caixas()
     #   return textopadrao, caixas

    #def botoes(self):
        #self.caixas = self.frames()
      #  self.textopadrao = self.frames()
        def paginadeart59():
            textopadrao()
            caixas['caixaai'].pack_forget()
            caixas['caixace'].pack_forget()
            caixas['caixapl'].pack_forget()
            caixas['caixaar'].pack_forget()
            caixas['caixatempestividade'].pack_forget()
            caixas['caixarecurso'].pack_forget()
            caixas['caixaart'].pack_forget()
            caixas['caixacnpj'].pack_forget()
            caixas['caixasei'].pack_forget()



        def paginademenu():
            caixas()
            #caixas['caixaai'].pack()
            #self.paginadeart59.pack_forget()
            #self.caixas


        """Barra de pesquisa"""
        lb_pes = Entry(self.frame_1, text="Digite sua busca aqui")
        lb_pes.configure(background='#fff', fg='black', font='Arial 10 ')
        lb_pes.place(relx=0.60, rely=0.4, relwidth=0.25, relheight=0.25)

        """Botao pesquisar"""
        btn_pes = ctk.CTkButton(self.frame_1, text='Pesquisar', fg_color='#fff', text_color='#000', font=('Arial', 14))
        btn_pes.place(relx=0.86, rely=0.4, relwidth=0.07, relheight=0.25)

        """Botao Menu"""
        btn_menu = ctk.CTkButton(self.frame_2, text='Menu', fg_color='#01509b', text_color='White',font=('Arial', 14),command=paginademenu)
        btn_menu.place(relx=0, rely=0, relwidth=1, relheight=0.08)

        """Botao Artigo 1"""
        btn_art1 = ctk.CTkButton(self.frame_2, text='Art 1º', fg_color='#01509b', text_color='White',font=('Arial', 14))
        btn_art1.place(relx=0, rely=0.08, relwidth=1, relheight=0.08)

        """Botao Artigo 6 A"""
        btn_art6a = ctk.CTkButton(self.frame_2, text='Art 6º a', fg_color='#01509b', text_color='White',font=('Arial', 14))
        btn_art6a.place(relx=0, rely=0.16, relwidth=1, relheight=0.08)

        """Botao Artigo 6 E"""
        btn_art6e = ctk.CTkButton(self.frame_2, text='Art 6º e', fg_color='#01509b', text_color='White',font=('Arial', 14))
        btn_art6e.place(relx=0, rely=0.24, relwidth=1, relheight=0.08)

        """Botao Artigo 16"""
        btn_art16 = ctk.CTkButton(self.frame_2, text='Art 16º', fg_color='#01509b', text_color='White',font=('Arial', 14))
        btn_art16.place(relx=0, rely=0.32, relwidth=1, relheight=0.08)

        """Botao Artigo 59"""
        btn_art59 = ctk.CTkButton(self.frame_2, text='Art 59º', fg_color='#01509b', text_color='White',font=('Arial', 14),command=paginadeart59)
        btn_art59.place(relx=0, rely=0.4, relwidth=1, relheight=0.08)

        paginademenu()





    def logo(self):
        """definir a logo do projeto"""
        logoimg = Image.open("log.png")
        self.lg = ImageTk.PhotoImage(logoimg)
        self.lbl = tk.Label(self.frame_1, image=self.lg)
        self.lbl.place(relx=0.07, rely=0.1, relwidth=0.35, relheight=0.8)
        self.lbl.image = self.lg

        """consulta de acordo com creas TO/BA/PR"""
        #def creas():





        """selecionar o arquivo"""
        def selecionar_arquivo():
            lbl2_selecionado = Label(self.frame_1)
            lbl2_selecionado.config(text="  ", background='white')
            lbl2_selecionado.place(relx=0.395, rely=0.45, relwidth=0.025, relheight=0.09)
            lbl_selecionado = Label(self.frame_3)
            lbl_selecionado.config(text="  ", background='#adadad')
            lbl_selecionado.place(relx=0.45, rely=0.10, relwidth=0.15, relheight=0.80)
            self.caixaai.delete("2.16", "2.80")
            self.caixaai.delete("3.7", "3.80")
            self.caixaai.delete("4.11", "4.80")
            self.caixaai.delete("5.5", "5.80")
            self.caixaai.delete("7.8","7.80")
            self.caixaai.delete("9.7", "9.80")
            self.caixaai.delete("10.5", "10.80")
            self.caixaai.delete("8.10", "8.80")
            #self.T.insert("2.80", str(pag_au), "red")  # Adiciona a tag "red" ao novo valor
            file_path = askopenfilename(filetypes=[("Arquivos PDF", "*.pdf")], defaultextension=".pdf")
            # Verifica se o usuário selecionou um arquivo ou cancelou o diálogo
            if file_path:
                print("Arquivo selecionado:", file_path)
                partes = file_path.split("Downloads/")
                if len(partes) > 1:
                    depois_downloads = partes[1]
                lbl_selecionado = Label(self.frame_3)
                lbl_selecionado.config(text=depois_downloads, background='#adadad')
                lbl_selecionado.place(relx=0.25, rely=0.10, relwidth=0.3, relheight=0.80)
                # Abre o arquivo PDF em modo leitura binária
                with open(file_path, 'rb') as pdf_file:
                    # Cria um objeto PDFReader
                    pdf_reader = PdfReader(pdf_file)
                    num_pages = len(pdf_reader.pages)
                    #num_paginas = pdf_reader.getNumPages()
                    print(num_pages)
                    qualcrea(pdf_file,num_pages)
                    #lerdados(pdf_reader, num_pages)
                    return pdf_reader

        def qualcrea(pdf_file, num_pages):
            pdf_reader = PdfReader(pdf_file)
            for page_num in range(num_pages):
                page = pdf_reader.pages[page_num]
                text = page.extract_text()
                        #print(text)
                autuado = re.search(r'Autuado(a):(.*)', text)
                print("autuado", autuado)
                match = re.search(r'\bCREA-\b(.{2})', text, re.IGNORECASE)
                nsei = re.search(r'Nº(.*)', text)

                print("numero so sei",nsei)
                #match1 = re.search(r'Autuado\(a\)', text)
                #result = match.group(1)
                #result1 = match1.group(1)

                        #match = re.search(r'\bCREA/\b(.{2})', text, re.IGNORECASE)
                print("qual crea?", match)

                if nsei:
                    result_nsei = nsei.group(1)
                    self.caixaai.insert("2.16", str(result_nsei), "red")  # Adiciona a tag "red" ao novo valor
                    self.caixaai.tag_config("red", foreground="red")  # Configura a cor vermelha para a tag "red"
                if match:
                    result = match.group(1)
                    # print('Encontrado:', result)
                    lbl2_selecionado = Label(self.frame_1)
                    lbl2_selecionado.config(text=result, background='#a1a1a1')
                    fonte = font.Font(size=18)
                    lbl2_selecionado["font"] = fonte
                    lbl2_selecionado.place(relx=0.395, rely=0.45, relwidth=0.025, relheight=0.09)
                    if result == "to":
                        creas(pdf_file, num_pages)
                    elif result == "BA" or result == "ba":
                        creas(pdf_file, num_pages)
                    elif result == "rn":
                        creas(pdf_file, num_pages)
                    elif result == "TO":
                        creas(pdf_file, num_pages)

                    break


        def creas(pdf_file,num_pages):
            pdf_reader = PdfReader(pdf_file)
            for page_num in range(num_pages):
                page = pdf_reader.pages[page_num]
                text = page.extract_text()
                print("a pagina atual é",page_num)
                pagautuado = re.search(r'Autuado\(a\)', text)
                pagmulta = re.search(r'Multa', text)

                #autuado = re.search(r'Autuado\(a\)(.{20})', text)
                #print(autuado)
                    #return result
                if pagautuado and pagmulta:
                    #result1 = match1.group(1)
                    pag_au = page_num + 1
                    # Inserir o novo valor extraído do PDF no widget Text
                    self.caixaai.insert("7.9", str(pag_au), "red")  # Adiciona a tag "red" ao novo valor
                    self.caixaai.tag_config("red", foreground="red")  # Configura a cor vermelha para a tag "red"
                    #self.autoflr = Label(self.frame_4)
                    #self.autoflr.config(text=pag_au, background='#e8e8e8',fg='red', font=('Arial', 10))
                    #self.autoflr.place(relx=0.08, rely=0.22, relwidth=0.05, relheight=0.12)
                    pagedoauto(pag_au, pdf_file)
                    #print("o autuado:",result1)
                    break

        def configdata(data):
            dia = data.group(1)
            mes = data.group(2)
            ano = data.group(3)
            def configmes():
                data_formatada = f"{dia} de {mes_escrito} de {ano}"
                self.caixaai.insert("10.6", str(data_formatada), "red")  # Adiciona a tag "red" ao novo valor
                self.caixaai.tag_config("red", foreground="red")
            if mes == '01':
                mes_escrito = "janeiro"
                configmes()
            elif mes == '02':
                mes_escrito = "fevereiro"
                configmes()
            elif mes == '03':
                mes_escrito = "março"
                configmes()
            elif mes == '04':
                mes_escrito = "abril"
                configmes()
            elif mes == '05':
                mes_escrito = "maio"
                configmes()
            elif mes == '06':
                mes_escrito = "junho"
                configmes()
            elif mes == '07':
                mes_escrito = "julho"
                configmes()
            elif mes == '08':
                mes_escrito = "agosto"
                configmes()
            elif mes == '09':
                mes_escrito = "setembro"
                configmes()
            elif mes == '10':
                mes_escrito = "outubro"
                configmes()
            elif mes == '11':
                mes_escrito = "novembro"
                configmes()
            elif mes == '12':
                mes_escrito = "dezembro"
                configmes()

        def pagedoauto(pag_au, pdf_file):
            pdf_reader = PdfReader(pdf_file)
            page = pdf_reader.pages[pag_au-1]
            text = page.extract_text()

            print("a pagina",text)
            artigo = re.search(r'Infração: PESSOA JUR(.{29})', text)
            multa = re.search(r'Multa de(.*)', text)
            data = re.search(r'em (\d{2})/(\d{2})/(\d{4})', text)
            nauto = re.search(r'Nº(.*)', text)
            descricao = re.search(r'DESCRIÇÃO:\n(.*?)(?=\.)', text, re.DOTALL)
            print("hehe",descricao)
            autuado = re.search(r'(.*)Autuado\(a\)', text)
            cnpj = re.search(r'\*{3}(\d+\.\d+)\*{3}', text)
            if cnpj:
                result_cnpj = cnpj.group(1)
                self.caixaai.insert("5.6", f"***{result_cnpj}***", "red")
                self.caixaai.tag_config("red", foreground="red")
                print(cnpj)
            if autuado:
                result_autuado = autuado.group(1)
                self.caixaai.insert("4.12", str(result_autuado), "red")  # Adiciona a tag "red" ao novo valor
                self.caixaai.tag_config("red", foreground="red")
                print("deu certo",result_autuado)

            print("o artigo",artigo)


            print(data)
            print(nauto)
            if multa:
                result_multa = multa.group(1)
                self.caixaai.insert("9.7", str(result_multa), "red")  # Adiciona a tag "red" ao novo valor
                self.caixaai.tag_config("red", foreground="red")
                #self.automultar = Label(self.frame_4)
                #self.automultar.config(text=result_multa, background='#e8e8e8',fg='red', font=('Arial', 10))
                #self.automultar.place(relx=0.1, rely=0.60, relwidth=0.09, relheight=0.12)
            if data:
                configdata(data)
            if artigo:
                result_artigo = artigo.group(1)
                print(result_artigo)
                if "LEIGA" in result_artigo:
                    self.caixaai.insert("3.8", str("Art. 6º da Lei Federal 5.194, de 1966"), "red")  # Adiciona a tag "red" ao novo valor
                    self.caixaai.tag_config("red", foreground="red")
                    print("artigo 6º")
                elif "SEM REGISTRO" in result_artigo:
                    self.caixaai.insert("3.8", str("Art. 59º da Lei Federal 5.194, de 1966"), "red")  # Adiciona a tag "red" ao novo valor
                    self.caixaai.tag_config("red", foreground="red")
                    print("artigo 59º")
                elif "CANCELADO" in result_artigo:
                    self.caixaai.insert("3.8", str("Art. 64º da Lei Federal 5.194, de 1966"), "red")  # Adiciona a tag "red" ao novo valor
                    self.caixaai.tag_config("red", foreground="red")
                    print("artigo 64º")




            if nauto:
                result_nauto = nauto.group(1)
                self.caixaai.insert("8.10", str(result_nauto), "red")  # Adiciona a tag "red" ao novo valor
                self.caixaai.tag_config("red", foreground="red")



            #print(multa)
            #if multa:
                #caracteres_seguintes = multa.group(1)
                #print(caracteres_seguintes)

        #def lerdados(pdf_reader, num_pages):
            #for page_num in range(num_pages):
                #page = pdf_reader.pages[page_num]
                #text = page.extract_text()

                #match1 = re.search(r'Autuado\(a\)', text)
                #if match1:
                #    result1 = match1.group()
                #    print('Encontrado:', result1)
                    # Itera por todas as páginas do arquivo
                    #for page_num in range(len(pdf_reader.pages)):
                    #    # Extrai o conteúdo da página atual
                    #    page = pdf_reader.pages[page_num]
                    #    text = page.extract_text()
                        #text1 = extract_text(file_path)
                        #qualcrea(match)
                        #print(page_num)
                        #return match

        #def qualcrea(match):
            #print("b", match)

            # Se o termo for encontrado, exibe o que vem depois dele

                #break

        #def creas():
        #    print("c", result)

            #match1 = re.search(r'Autuado\(a\)', text)
            #match2 = re.search(r'Multa', text)
            #print("a", match1)
            ##print("d", result2)
            #if result == "to":
            #            print("haha")
            #            if match1 and match2:
            #                        # result = match1.group()
            #                print(page_num + 1)
            #                #break
                                #if match1:
                                #    result2 = match1.group(1)
                                #    print(result2)
                                #    print(match1)
                                #    print(match)
                                #else:
                                #    print("Padrão 'Multa' não encontrado.")
                                #break
                    #    else:
                    #        print("Palavra não encontrada.")
            #else:
            #    print("Seleção de arquivo cancelada.")

        btn_selecionar = ctk.CTkButton(self.frame_3, text="Selecionar arquivo", command=selecionar_arquivo)
        btn_selecionar.place(relx=0.65, rely=0.10, relwidth=0.15, relheight=0.80)


App()
root.mainloop()